---
name: xhs-content-ops
description: '小红书复合内容运营技能。组合浏览器浏览、发布、互动等能力完成运营工作流。

  当用户要求竞品分析、热点追踪、内容创作发布、互动管理等复合任务时触发。

  '
metadata:
  openclaw:
    emoji: 📊
---

# 小红书复合内容运营技能

 用于代替用户在小红书（xhs）平台上完成多步骤组合的运营任务。

## 技能依赖

本技能组合两个底层技能：
- **browser**（数据采集）：浏览小红书搜索页、笔记详情、用户主页
- **xhs-interact**（社交互动）：评论、点赞、收藏

## ⚙️ 执行方式（强制）

本技能涉及多步骤生产流程，你应该 self-spawn 一个 subagent 来执行，原因：subagent 独立上下文，不会因对话历史积累而降低输出质量。

你只负责跟进subagent的执行，避免它们长时间卡在某个步骤，必要时可以提供提示或调整执行策略。

---

## 小红书 URL 格式参考

| 页面 | URL |
|------|-----|
| 搜索结果 | `https://www.xiaohongshu.com/search_result?keyword=关键词` |
| 笔记详情 | `https://www.xiaohongshu.com/explore/{feed_id}?xsec_token={token}&xsec_source=pc_feed` |
| 用户主页 | `https://www.xiaohongshu.com/user/profile/{user_id}` |

**提取 feed_id 和 xsec_token**：打开笔记页面后，从浏览器地址栏 URL 中读取：
- `feed_id` = `/explore/` 后面的路径段（如 `64abc123def456`）
- `xsec_token` = URL 参数 `xsec_token` 的值

---

## 输入判断

1. 用户要求"竞品分析 / 分析竞品 / 对比笔记"：执行**竞品分析流程**。
2. 用户要求"热点追踪 / 热门话题 / 趋势分析"：执行**热点追踪流程**。
3. 用户要求"创作发布 / 研究话题后发布 / 一键创作"：执行**内容创作流程**。
4. 用户要求"互动管理 / 批量互动 / 评论策略"：执行**互动管理流程**。

## 必做约束

- 复合流程中每一步都应向用户报告进度。
- 评论类操作使用 xhs-interact 技能。
- **控制整体频率**：分批、间隔执行，不要一次性处理大量任务。
- 所有数据分析结果使用 markdown 表格结构化呈现。

---

## 竞品分析

目标：搜索竞品笔记 → 阅读详情 → 整理分析报告。

```
1. 导航到搜索页，按"最多点赞"排序
   URL: https://www.xiaohongshu.com/search_result?keyword=目标关键词
2. Snapshot 获取搜索结果列表，记录前 5-10 篇高互动笔记的标题、点赞数、URL
3. 逐一打开 3-5 篇笔记，snapshot 读取完整正文、标签、评论数、收藏数
4. 整理分析报告（markdown 表格）：
   - 标题风格分析
   - 正文结构（开头/中间/结尾）
   - 话题标签使用
   - 互动数据对比（点赞/评论/收藏）
   - 共性特征和差异化策略
```

---

## 热点追踪

目标：搜索热门关键词 → 分析趋势 → 提供选题建议。

```
1. 按最新排序，观察近期热度：
   URL: https://www.xiaohongshu.com/search_result?keyword=关键词（页面切换"最新"Tab）
2. 按最多点赞，找爆款：
   URL: https://www.xiaohongshu.com/search_result?keyword=关键词（页面切换"最热"Tab）
3. Snapshot 读取结果，提炼：
   - 近期高频话题和关键词
   - 爆款内容的共同特征
   - 选题建议
```

---

## 内容创作发布

目标：研究话题 → 辅助生成草稿 → 用户确认 → 发布。

```
1. 搜索参考内容（按最多点赞）
2. 打开 2-3 篇参考笔记，读取正文、标签结构
3. 基于分析生成草稿（标题 ≤20 字，正文 ≤1000 字，加话题标签）
4. 通过 AskUserQuestion 确认草稿
```

---

## 互动管理

目标：浏览目标笔记 → 有策略地评论/点赞/收藏。

```
1. 搜索目标笔记（按最新排序）
2. 打开笔记，从地址栏提取 feed_id 和 xsec_token
3. 按照 xhs-interact 流程，通过 browser 工具完成评论/点赞/收藏
4. 每次互动之间保持 30-60 秒间隔，每天评论不超过 20 条
```

---

## 运营建议

- **竞品分析频率**：每周 1-2 次，跟踪竞品动态。
- **热点追踪频率**：每天 1 次，抓住时效性内容。
- **发布时间**：工作日 12:00-13:00、18:00-21:00 为高峰时段。
- **内容合规**：不得出现引流导流信息，不得搬运他人内容。

## 失败处理

- **搜索页面出现登录墙**：遵循 browser-guide 第 6 节 QR 登录流程，扫码后重试。
- **笔记无法访问**：该笔记可能已删除或设为私密，跳过。
- **发布失败**：参考 xhs-publish 的失败处理。
- **互动失败**：参考 xhs-interact 的失败处理。

## 发布记录（强制）

发布成功后，**必须**立即调用 `published-track` 技能记录发布信息：

```bash
./skills/published-track/scripts/record.sh \
  --platform xhs \
  --title "标题" \
  --content-type post \
  --source-folder "<原始文件夹路径>" \
  --publish-url "<发布URL>" \
  --publish-date "$(date +%Y-%m-%d)"
```

`--source-folder` 为原始内容所在的相对路径（如 `output_articles/xxx` 或 `output_videos/xxx`）。
`--publish-url` 为发布后获得的 URL，若发布失败则留空并在 `--notes` 中注明原因。

执行 `./skills/published-track/scripts/init-db.sh`（幂等，重复执行无副作用）。
