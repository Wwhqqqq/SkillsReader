---
name: xhs-note-creator
description: 小红书笔记创作与一键发布技能。当用户需要 "发小红书"、"创建小红书笔记"、"发布小红书"、"写一篇小红书"、生成小红书内容、制作小红书卡片、或提到 "xhs"、"redbook"、"红书" 时使用此技能。涵盖完整流程：AI 创作内容 → 卡片渲染 → 自动 Cookie 管理 → 一键发布。
---

# 小红书笔记创作与发布技能

根据用户需求，一站式完成：AI 创作笔记内容、生成精美图片卡片、自动管理 Cookie、一键发布到小红书。

## 核心原则

- 默认使用 **本地 API 签名模式** 发布（`xhs` 库直连，比 MCP 浏览器自动化更稳定）
- Cookie 由 `scripts/setup.py` 自动从 MCP Server 的 `cookies.json` 提取，无需手动配置
- Windows 环境下所有 Python 命令需加 `PYTHONIOENCODING=utf-8` 避免 GBK 编码错误

---

## 第一步：环境检查（首次使用或出问题时执行）

在开始创建笔记之前，运行状态检查确认一切就绪：

```bash
python <skill-dir>/scripts/setup.py --check
```

如果检查发现问题，运行一键配置：

```bash
python <skill-dir>/scripts/setup.py
```

setup.py 自动完成：依赖检查安装 → 搜索 cookies.json → 提取 Cookie → 写入 .env → 验证。

<skill-dir> 为技能安装路径，通常为 `~/.claude/skills/xhs-note-creator`。

---

## 第二步：创作笔记内容

根据用户提供的主题或资料，创作小红书风格的笔记内容：

**标题要求**：不超过 20 字，吸引眼球，可用数字/疑问句/感叹号增强吸引力。

**正文要求**：段落清晰，点缀少量 Emoji（每段 1-2 个），短句短段。结尾附 5-10 个 SEO 标签（格式：`#标签1 #标签2 ...`）。

**内容存档**：将文案保存到项目 `data/` 目录下，按发布时间归档：

```
data/
└── YYYY-MM-DD-HHMM/
    ├── text/
    │   ├── content.md    # 完整笔记（含 YAML front matter）
    │   ├── render.md     # 渲染用 Markdown
    │   └── title.txt     # 纯文本标题
    └── image/
        ├── cover.png     # 封面卡片
        ├── card_1.png    # 正文卡片
        └── ...
```

---

## 第三步：生成渲染用 Markdown

**重要：此 Markdown 专为图片渲染设计，禁止直接使用第二步的笔记正文。**

格式要求：

```markdown
---
emoji: "🚀"
title: "封面大标题（≤15字）"
subtitle: "封面副标题（≤15字）"
---

# 正文内容...

---

# 第二张卡片内容...
```

分页策略：
- 需要精确切分 → 用 `---` 手动分页，配合 `-m separator`（默认）
- 内容长短不稳定 → 使用 `-m auto-split`

---

## 第四步：渲染图片卡片

```bash
cd <project>/data/<timestamp>/image
PYTHONIOENCODING=utf-8 python <skill-dir>/scripts/render_xhs.py ../text/render.md [options]
```

**默认参数**：`-t sketch -m separator`（sketch 主题 + 手动分页）

常用选项：

| 参数 | 说明 |
|------|------|
| `-t sketch` | 手绘素描风格（默认） |
| `-t playful-geometric` | 活泼几何风格 |
| `-t neo-brutalism` | 新粗野主义风格 |
| `-t botanical` | 植物清新风格 |
| `-t professional` | 专业商务风格 |
| `-t retro` | 复古风格 |
| `-t terminal` | 终端黑客风格 |
| `-m separator` | 按 `---` 分隔（默认） |
| `-m auto-split` | 自动分页（推荐内容长短不定时） |
| `-m auto-fit` | 固定尺寸自动缩放 |
| `-m dynamic` | 动态分页 |

---

## 第五步：发布到小红书

**前置条件**：已运行 `scripts/setup.py` 完成 Cookie 配置。

发布脚本会按以下顺序查找 `.env` 中的 Cookie：
1. 当前工作目录
2. 技能根目录（`setup.py` 写入的位置）

```bash
cd <project>
PYTHONIOENCODING=utf-8 python <skill-dir>/scripts/publish_xhs.py \
  --title "标题（≤20字）" \
  --desc "笔记正文描述" \
  --images cover.png card_1.png card_2.png \
  --public
```

> **默认以「仅自己可见」发布**，加 `--public` 才会公开。建议先不加 `--public` 预览确认，确认无误后再加 `--public` 发布。

其他选项：
- `--api-mode`：通过 API 服务发布（需 xhs-api 服务运行中）
- `--post-time "2024-12-01 10:00:00"`：定时发布
- `--dry-run`：仅验证参数，不实际发布

---

## Cookie 管理

### 首次配置

```bash
python <skill-dir>/scripts/setup.py
```

### Cookie 过期后刷新

当 Cookie 过期（发布失败 + 提示签名错误），执行：

```bash
# 1. 重新登录（生成新的 cookies.json）
<project>/xhs-mcp-server/xiaohongshu-login-windows-amd64.exe

# 2. 同步到 .env
python <skill-dir>/scripts/sync_cookie.py
```

### 手动指定 MCP 目录

```bash
python <skill-dir>/scripts/sync_cookie.py --mcp-dir <path/to/xhs-mcp-server>
```

---

## 故障排查

### 发布失败：签名错误 (sign/signature error)

1. Cookie 可能已过期 → 运行 `sync_cookie.py` 刷新
2. 确保 Cookie 包含 `a1` 和 `web_session` 字段
3. 重新运行 MCP 登录工具扫码

### 渲染失败：UnicodeEncodeError (GBK)

Windows 特有编码问题，在所有 Python 命令前加 `PYTHONIOENCODING=utf-8`。

### 找不到 cookies.json

1. 用 `--mcp-dir` 显式指定 MCP Server 目录
2. 检查 MCP Server 是否至少运行过一次登录

### 找不到标题输入框 (MCP 发布工具)

这是 MCP 浏览器自动化的已知问题。改用本技能的 `publish_xhs.py`（API 直连模式）即可解决。

---

## 技能资源

### 核心脚本
- `scripts/setup.py` — **一键配置**：依赖安装 + Cookie 提取 + .env 生成
- `scripts/sync_cookie.py` — **Cookie 同步**：cookies.json → .env
- `scripts/render_xhs.py` — **卡片渲染**：8 种主题 + 4 种分页模式
- `scripts/publish_xhs.py` — **发布脚本**：API 直连 + 本地签名
- `scripts/render_xhs_v2.py` — 渲染 V2（备用，7 种渐变色彩风格）

### 模板与样式
- `assets/cover.html` — 封面 HTML 模板
- `assets/card.html` — 正文卡片 HTML 模板
- `assets/styles.css` — 公共容器样式
- `assets/themes/` — 各主题 CSS 文件（8 种）

### 参考文档
- `references/params.md` — 完整参数参考（主题/模式/发布参数）
