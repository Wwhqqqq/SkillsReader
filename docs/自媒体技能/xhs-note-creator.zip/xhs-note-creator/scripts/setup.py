#!/usr/bin/env python3
"""
小红书技能一键配置脚本

自动完成以下配置：
1. 检查并安装 Python 依赖
2. 从 MCP Server 的 cookies.json 自动提取 Cookie
3. 写入 .env 文件供 publish_xhs.py 使用
4. 验证 Cookie 有效性

使用方式:
    python setup.py                    # 交互式配置
    python setup.py --mcp-dir <path>   # 指定 MCP Server 目录
    python setup.py --cookie <str>     # 直接提供 Cookie 字符串
    python setup.py --check            # 仅检查当前配置状态
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional, Dict, List

SKILL_DIR = Path(__file__).parent.parent
ENV_FILE = SKILL_DIR / ".env"

REQUIRED_PACKAGES = {
    "xhs": "xhs",
    "dotenv": "python-dotenv",
    "requests": "requests",
    "playwright": "playwright",
}

REQUIRED_COOKIE_FIELDS = ["a1", "web_session"]

# 常见的 cookies.json 位置
COMMON_MCP_PATHS = [
    Path.cwd() / "xhs-mcp-server" / "cookies.json",
    Path.home() / ".claude" / "xhs-mcp-server" / "cookies.json",
    Path.home() / "xhs-mcp-server" / "cookies.json",
]


def check_dependencies() -> Dict[str, bool]:
    """检查 Python 依赖是否安装"""
    results = {}
    for import_name, pkg_name in REQUIRED_PACKAGES.items():
        try:
            __import__(import_name.replace("-", "_"))
            results[pkg_name] = True
        except ImportError:
            results[pkg_name] = False
    return results


def install_dependencies(missing: List[str]) -> bool:
    """安装缺失的依赖"""
    if not missing:
        return True

    print(f"\n📦 安装缺失的依赖: {', '.join(missing)}")
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", *missing],
            stdout=subprocess.DEVNULL,
        )
        print("✅ 依赖安装完成")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 依赖安装失败: {e}")
        return False


def find_cookies_json(extra_paths: List[str] = None) -> Optional[Path]:
    """自动查找 cookies.json（多策略搜索）"""
    search_paths = []

    if extra_paths:
        search_paths = [Path(p) for p in extra_paths]

    # 策略1: 当前目录向上4级搜索 xhs-mcp-server/cookies.json
    current = Path.cwd()
    for _ in range(5):
        candidate = current / "xhs-mcp-server" / "cookies.json"
        if candidate not in search_paths:
            search_paths.append(candidate)
        current = current.parent

    # 策略2: 常见固定路径
    search_paths.extend(COMMON_MCP_PATHS)

    for path in search_paths:
        if path.exists():
            return path

    return None


def cookies_json_to_string(cookies_path: Path) -> str:
    """将 cookies.json 转换为 Cookie 字符串"""
    with open(cookies_path, "r", encoding="utf-8") as f:
        cookies = json.load(f)

    if isinstance(cookies, dict):
        cookies = [{"name": k, "value": v} for k, v in cookies.items()]

    parts = []
    for c in cookies:
        if isinstance(c, dict):
            name = c.get("name", "")
            value = c.get("value", "")
            if name and value:
                parts.append(f"{name}={value}")

    return "; ".join(parts)


def validate_cookie(cookie_str: str) -> List[str]:
    """验证 Cookie 是否包含必需字段，返回缺失字段列表"""
    cookie_dict = {}
    for item in cookie_str.split(";"):
        item = item.strip()
        if "=" in item:
            key, value = item.split("=", 1)
            cookie_dict[key.strip()] = value.strip()

    missing = [f for f in REQUIRED_COOKIE_FIELDS if f not in cookie_dict]
    return missing


def write_env_file(cookie_str: str, path: Path = None) -> Path:
    """写入 .env 文件"""
    if path is None:
        path = ENV_FILE

    content = f"# 小红书 Cookie - 由 setup.py 自动生成\n"
    content += f"# 生成时间: {__import__('datetime').datetime.now()}\n"
    content += f"# 如需刷新: python scripts/sync_cookie.py\n\n"
    content += f"XHS_COOKIE={cookie_str}\n"

    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

    return path


def test_connection(cookie_str: str) -> bool:
    """测试 Cookie 是否能连接小红书"""
    try:
        from xhs import XhsClient
        from xhs.help import sign as local_sign

        def sign_func(uri, data=None, a1="", web_session=""):
            return local_sign(uri, data, a1=a1)

        client = XhsClient(cookie=cookie_str, sign=sign_func)
        info = client.get_self_info()
        nickname = info.get("nickname", "未知")
        if nickname and nickname != "未知":
            print(f"✅ 连接成功！当前登录用户: {nickname}")
            return True
        else:
            print(f"⚠️ 获取用户信息失败，但 Cookie 格式有效")
            print("  发布功能通常不受影响，可尝试直接发布")
            return True
    except Exception as e:
        print(f"⚠️ 连接测试异常: {e}")
        print("  这不一定表示 Cookie 无效，发布功能可能仍可用")
        print("  如发布失败，请重新运行 MCP 登录工具刷新 Cookie")
        return True  # 不阻塞流程


def print_status():
    """打印当前配置状态"""
    print("=" * 50)
    print("  小红书技能配置状态")
    print("=" * 50)

    # 依赖检查
    deps = check_dependencies()
    all_ok = True
    print("\n📦 依赖状态:")
    for pkg, installed in deps.items():
        icon = "✅" if installed else "❌"
        print(f"  {icon} {pkg}")
        if not installed:
            all_ok = False

    # .env 文件检查
    print(f"\n🔑 Cookie 配置:")
    if ENV_FILE.exists():
        print(f"  ✅ .env 文件存在: {ENV_FILE}")
        os.environ.get("XHS_COOKIE", "")
        from dotenv import load_dotenv
        load_dotenv(ENV_FILE)
        cookie = os.getenv("XHS_COOKIE", "")
        if cookie and cookie != "your_cookie_string_here":
            missing = validate_cookie(cookie)
            if missing:
                print(f"  ⚠️ Cookie 缺少字段: {missing}")
                all_ok = False
            else:
                print(f"  ✅ Cookie 字段完整 (a1, web_session)")
        else:
            print(f"  ❌ Cookie 未配置或为默认值")
            all_ok = False
    else:
        print(f"  ❌ .env 文件不存在，请运行: python scripts/setup.py")
        all_ok = False

    # cookies.json 检查
    print(f"\n🍪 MCP Cookie 文件:")
    cookie_path = find_cookies_json()
    if cookie_path:
        print(f"  ✅ 找到: {cookie_path}")
    else:
        print(f"  ⚠️ 未找到 cookies.json")

    print(f"\n{'✅ 所有检查通过！' if all_ok else '❌ 存在问题需要修复'}")
    return all_ok


def main():
    parser = argparse.ArgumentParser(
        description="小红书技能一键配置工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python setup.py                          # 自动查找 cookies.json 并配置
  python setup.py --check                  # 仅检查当前状态
  python setup.py --mcp-dir ./xhs-mcp-server  # 指定 MCP 目录
  python setup.py --cookie "a1=xxx; web_session=yyy"  # 直接提供 Cookie
        """,
    )
    parser.add_argument("--check", action="store_true", help="仅检查配置状态")
    parser.add_argument("--mcp-dir", help="MCP Server 目录路径")
    parser.add_argument("--cookie", help="直接提供 Cookie 字符串")
    parser.add_argument("--skip-test", action="store_true", help="跳过连接测试")

    args = parser.parse_args()

    if args.check:
        ok = print_status()
        sys.exit(0 if ok else 1)

    print("🚀 小红书技能 - 一键配置")
    print("=" * 50)

    # Step 1: 检查依赖
    print("\n📦 Step 1/4: 检查 Python 依赖...")
    deps = check_dependencies()
    missing = [pkg for pkg, ok in deps.items() if not ok]
    if missing:
        if not install_dependencies(missing):
            sys.exit(1)
    else:
        print("✅ 所有依赖已安装")

    # Step 2: 获取 Cookie
    print("\n🔑 Step 2/4: 获取 Cookie...")
    cookie_str = None

    if args.cookie:
        cookie_str = args.cookie
        print("✅ 使用命令行提供的 Cookie")
    else:
        # 查找 cookies.json
        extra_paths = []
        if args.mcp_dir:
            extra_paths.append(Path(args.mcp_dir) / "cookies.json")

        cookie_path = find_cookies_json(extra_paths)
        if cookie_path:
            print(f"✅ 找到 cookies.json: {cookie_path}")
            cookie_str = cookies_json_to_string(cookie_path)
        else:
            print("❌ 未找到 cookies.json 文件")
            print("\n请通过以下方式提供 Cookie:")
            print("  1. 运行 MCP 登录工具生成 cookies.json")
            print("  2. 使用 --mcp-dir 指定 MCP Server 目录")
            print("  3. 使用 --cookie 直接提供 Cookie 字符串")
            print("\n搜索路径:")
            for p in COMMON_MCP_PATHS:
                print(f"  - {p}")
            sys.exit(1)

    # Step 3: 验证 Cookie
    print("\n🔍 Step 3/4: 验证 Cookie...")
    missing = validate_cookie(cookie_str)
    if missing:
        print(f"❌ Cookie 缺少必需字段: {missing}")
        print("请确保 Cookie 包含 a1 和 web_session 字段")
        print("可能需要重新运行 MCP 登录工具")
        sys.exit(1)
    print("✅ Cookie 字段完整")

    # Step 4: 写入 .env
    print("\n💾 Step 4/4: 写入配置...")
    env_path = write_env_file(cookie_str)
    print(f"✅ 配置已写入: {env_path}")

    # 可选：测试连接
    if not args.skip_test:
        print("\n🔗 测试连接...")
        test_connection(cookie_str)

    print("\n" + "=" * 50)
    print("✅ 配置完成！现在可以使用以下命令发布笔记：")
    print(f"  python {SKILL_DIR / 'scripts' / 'publish_xhs.py'} --title '标题' --desc '描述' --images cover.png --public")
    print("\n💡 如果 Cookie 过期，运行以下命令刷新：")
    print(f"  python {SKILL_DIR / 'scripts' / 'sync_cookie.py'}")


if __name__ == "__main__":
    main()
