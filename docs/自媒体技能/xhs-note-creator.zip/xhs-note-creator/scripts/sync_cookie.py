#!/usr/bin/env python3
"""
小红书 Cookie 同步工具

从 MCP Server 的 cookies.json 提取 Cookie 并更新 .env 文件。
当 Cookie 过期后重新扫码登录时，运行此脚本即可同步。

使用方式:
    python sync_cookie.py                    # 自动查找并同步
    python sync_cookie.py --mcp-dir <path>   # 指定 MCP 目录
    python sync_cookie.py --check            # 仅检查 Cookie 是否有效
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, List

SKILL_DIR = Path(__file__).parent.parent
ENV_FILE = SKILL_DIR / ".env"

COMMON_MCP_PATHS = [
    Path.cwd() / "xhs-mcp-server" / "cookies.json",
    Path.home() / ".claude" / "xhs-mcp-server" / "cookies.json",
    Path.home() / "xhs-mcp-server" / "cookies.json",
]


def find_cookies_json(extra_paths: List[str] = None) -> Optional[Path]:
    """自动查找 cookies.json（多策略搜索）"""
    search_paths = []

    if extra_paths:
        search_paths.extend([Path(p) for p in extra_paths])

    # 策略1: 当前目录向上3级搜索 xhs-mcp-server/cookies.json
    current = Path.cwd()
    for _ in range(4):
        candidate = current / "xhs-mcp-server" / "cookies.json"
        if candidate not in search_paths:
            search_paths.append(candidate)
        current = current.parent

    # 策略2: 常见固定路径
    search_paths.extend(COMMON_MCP_PATHS)

    for path in search_paths:
        if path.exists():
            return path
    return None


def cookies_json_to_string(cookies_path: Path) -> str:
    """cookies.json → Cookie 字符串"""
    with open(cookies_path, "r", encoding="utf-8") as f:
        cookies = json.load(f)

    if isinstance(cookies, dict):
        cookies = [{"name": k, "value": v} for k, v in cookies.items()]

    parts = []
    for c in cookies:
        if isinstance(c, dict):
            name = c.get("name", "")
            value = c.get("value", "")
            if name and value:
                parts.append(f"{name}={value}")

    return "; ".join(parts)


def validate_cookie(cookie_str: str) -> List[str]:
    """验证 Cookie 字段，返回缺失列表"""
    cookie_dict = {}
    for item in cookie_str.split(";"):
        item = item.strip()
        if "=" in item:
            key, value = item.split("=", 1)
            cookie_dict[key.strip()] = value.strip()

    return [f for f in ["a1", "web_session"] if f not in cookie_dict]


def test_cookie(cookie_str: str) -> bool:
    """测试 Cookie 是否有效"""
    try:
        from xhs import XhsClient
        from xhs.help import sign as local_sign

        def sign_func(uri, data=None, a1="", web_session=""):
            return local_sign(uri, data, a1=a1)

        client = XhsClient(cookie=cookie_str, sign=sign_func)
        info = client.get_self_info()
        nickname = info.get("nickname", "")
        if nickname:
            print(f"  ✅ Cookie 有效，用户: {nickname}")
        else:
            print(f"  ⚠️ 无法获取用户信息，但 Cookie 格式有效")
        return True
    except Exception as e:
        print(f"  ⚠️ 连接测试异常: {e}")
        print(f"  发布功能可能仍可用，如失败请刷新 Cookie")
        return True  # 不阻塞


def main():
    parser = argparse.ArgumentParser(
        description="同步小红书 Cookie（cookies.json → .env）"
    )
    parser.add_argument("--mcp-dir", help="MCP Server 目录路径")
    parser.add_argument("--check", action="store_true", help="仅检查当前 Cookie 有效性")

    args = parser.parse_args()

    # 查找 cookies.json
    extra = [Path(args.mcp_dir) / "cookies.json"] if args.mcp_dir else []
    cookie_path = find_cookies_json(extra)

    if not cookie_path:
        print("❌ 未找到 cookies.json")
        print("\n请确保已运行 MCP 登录工具生成 cookies.json")
        print("或使用 --mcp-dir 指定 MCP Server 目录")
        sys.exit(1)

    print(f"📂 读取: {cookie_path}")

    # 转换
    cookie_str = cookies_json_to_string(cookie_path)

    # 验证
    missing = validate_cookie(cookie_str)
    if missing:
        print(f"❌ Cookie 缺少字段: {missing}")
        sys.exit(1)
    print(f"✅ Cookie 字段完整 (a1, web_session)")

    if args.check:
        test_cookie(cookie_str)
        sys.exit(0)

    # 写入 .env
    content = (
        f"# 小红书 Cookie - 同步自 {cookie_path}\n"
        f"# 同步时间: {datetime.now()}\n"
        f"# 下次同步: python {Path(__file__).resolve()}\n\n"
        f"XHS_COOKIE={cookie_str}\n"
    )

    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"✅ 已同步到: {ENV_FILE}")

    # 测试
    print("\n🔗 验证连接...")
    test_cookie(cookie_str)


if __name__ == "__main__":
    main()
