# xhs-note-creator

> Claude Code Skill — AI 驱动的内容创作工具链，8 种视觉主题 + 4 种智能分页模式

一个为 [Claude Code](https://claude.ai/code) 构建的技能包，将 AI 内容创作、精美卡片渲染和发布流程整合为一条全链路工作流。

---

## 功能亮点

- **AI 内容创作** — Claude Code 自动撰写标题、正文、SEO 标签
- **8 种视觉主题** — `sketch` · `playful-geometric` · `neo-brutalism` · `botanical` · `professional` · `retro` · `terminal` · `default`
- **4 种智能分页** — 手动分隔 / 自动拆分 / 缩放适配 / 动态高度
- **一键配置** — `setup.py` 自动安装依赖、提取认证信息、生成配置文件
- **高清渲染** — 1080×1440px @ 2x DPR，Playwright 浏览器引擎

---

## 主题预览

| Sketch | Playful Geometric | Neo Brutalism |
|--------|------------------|---------------|
| ![](demos/Sketch/cover.png) | ![](demos/playful-geometric/cover.png) | ![](demos/neo-brutalism/cover.png) |

| Botanical | Professional | Retro | Terminal |
|-----------|-------------|-------|----------|
| ![](demos/botanical/cover.png) | ![](demos/professional/cover.png) | ![](demos/retro/cover.png) | ![](demos/terminal/cover.png) |

> 更多示例见 [`demos/`](demos/)

---

## 快速开始

### 环境要求

- Python 3.10+
- Claude Code（已启用 Skills 功能）

### 安装技能

```bash
# 克隆到 Claude Code Skills 目录
mkdir -p ~/.claude/skills
cd ~/.claude/skills
git clone https://github.com/YOUR_USERNAME/xhs-note-creator.git
```

### 一键配置

```bash
cd ~/.claude/skills/xhs-note-creator
python scripts/setup.py
```

`setup.py` 自动完成：
1. 检查并安装 Python 依赖
2. 搜索本地的认证信息
3. 写入配置文件
4. 验证环境是否就绪

---

## 使用方式

### 在 Claude Code 中使用

直接跟 Claude 说：

> "帮我写一篇关于 XX 主题的笔记"

Claude 会自动调用此技能，走完整条管线：
1. **选题与文案** — AI 生成标题、正文、标签
2. **卡片排版** — 生成带 YAML front matter 的渲染 Markdown
3. **图片渲染** — Playwright 渲染高清卡片 PNG
4. **发布** — 一键发布（需认证配置）

### 手动渲染卡片

```bash
# 默认：sketch 主题 + 手动分页
python scripts/render_xhs.py content.md

# 自动分页（推荐：内容长短不一定时）
python scripts/render_xhs.py content.md -m auto-split

# 切换主题
python scripts/render_xhs.py content.md -t neo-brutalism -m auto-split
```

### 手动发布

```bash
python scripts/publish_xhs.py \
  --title "你的标题" \
  --desc "正文描述" \
  --images cover.png card_1.png card_2.png \
  --public
```

---

## 主题一览

| 主题 | 参数 `-t` | 风格 |
|------|----------|------|
| Sketch | `sketch` | 手绘素描风格（默认） |
| Playful Geometric | `playful-geometric` | 几何图形 + 渐变色彩 |
| Neo Brutalism | `neo-brutalism` | 粗黑边框 + 高饱和撞色 |
| Botanical | `botanical` | 清新植物绿调配色 |
| Professional | `professional` | 蓝色渐变商务风 |
| Retro | `retro` | 复古暖橙色调 |
| Terminal | `terminal` | 终端黑客暗色风格 |
| Default | `default` | 简洁浅色底 |

---

## 分页模式

| 模式 | 参数 `-m` | 适用场景 |
|------|----------|---------|
| Separator | `separator` | 用 `---` 手动分页 |
| Auto Split | `auto-split` | 内容长短不定，自动平衡每页 |
| Auto Fit | `auto-fit` | 固定卡片尺寸，缩放内容适配 |
| Dynamic | `dynamic` | 根据内容动态调整卡片高度 |

---

## 渲染 Markdown 格式

```markdown
---
emoji: "🚀"
title: "封面标题（≤15字）"
subtitle: "封面副标题（≤15字）"
---

# 第一张卡片内容

---

# 第二张卡片内容
```

---

## 项目结构

```
xhs-note-creator/
├── SKILL.md              # 技能定义与工作流
├── README.md             # 项目文档
├── requirements.txt      # Python 依赖
├── env.example.txt       # 环境变量模板
├── .gitignore            # 排除敏感文件
├── scripts/
│   ├── setup.py          # 一键环境配置
│   ├── sync_cookie.py    # 认证信息同步
│   ├── render_xhs.py     # 主渲染引擎（8 主题 + 4 分页）
│   ├── render_xhs_v2.py  # 备用渲染器（7 种渐变风格）
│   └── publish_xhs.py    # 发布脚本（API 直连）
├── assets/
│   ├── cover.html        # 封面 HTML 模板
│   ├── card.html         # 卡片 HTML 模板
│   ├── styles.css        # 公共样式
│   └── themes/           # 8 套主题 CSS
├── references/
│   └── params.md         # 完整参数参考文档
└── demos/                # 各主题渲染效果图
```

---

## 常见问题

### Windows 下报 GBK 编码错误

```bash
PYTHONIOENCODING=utf-8 python scripts/render_xhs.py content.md
```

### 认证过期

```bash
python scripts/sync_cookie.py
```

### 缺少依赖

```bash
pip install -r requirements.txt
playwright install chromium
```

---

## 安全提醒

- `.env` 和 `cookies.json` 已被 `.gitignore` 排除，请勿手动提交
- 不要将包含认证信息的配置文件分享给他人
- Cookie 有过期时间，过期后重新获取即可

---

## 致谢

- [Claude Code](https://claude.ai/code) — 本项目的 AI 开发搭档，从代码到文案全程协作
- [Playwright](https://playwright.dev/) — 浏览器自动化渲染引擎
- [xhs](https://github.com/ReaJason/xhs) — Python 小红书 API 客户端

---

## License

MIT License © 2026
